/*
 * bloom.h - Bloom filter (probabilistic set-membership structure).
 *
 * A Bloom filter answers "is key in this SSTable?" with:
 *   - "definitely NOT present"  (100% reliable)  -> skip the disk read
 *   - "possibly present"        (small false-positive probability)
 *
 * It never gives false negatives, so skipping a table on "no" is always safe.
 * Cost of a query: O(k) bit probes, independent of the number of keys.
 */
#ifndef BLOOM_H
#define BLOOM_H

#include <stdint.h>
#include <stddef.h>

typedef struct {
    uint8_t *bits;     /* bit array, nbits long                */
    uint64_t nbits;    /* m : number of bits                   */
    uint32_t k;        /* number of hash functions             */
} Bloom;

/* Size the filter for `expected_keys` keys at `bits_per_key` bits each.
 * With 10 bits/key and k=7 the false-positive rate is about 0.8%. */
Bloom *bloom_create(uint64_t expected_keys, unsigned bits_per_key);

/* Allocate an all-zero filter with explicit (m, k) - used when loading from disk. */
Bloom *bloom_alloc(uint64_t nbits, uint32_t k);

void   bloom_add(Bloom *b, uint64_t key);
int    bloom_may_contain(const Bloom *b, uint64_t key);   /* 0 = definitely absent */
size_t bloom_nbytes(const Bloom *b);
void   bloom_free(Bloom *b);

#endif /* BLOOM_H */
