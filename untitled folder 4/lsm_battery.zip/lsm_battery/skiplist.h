/*
 * skiplist.h - MemTable implementation: a sorted Skip List.
 *
 * A skip list is a linked list with extra "express lane" pointers. Each node
 * gets a random height (P(height>=h) = 2^-(h-1)), so on average the structure
 * behaves like a balanced search tree without any rotations.
 *
 *   level 3:  head ------------------------> 40 ----------------> NULL
 *   level 2:  head --------> 17 ------------> 40 -------> 71 ----> NULL
 *   level 1:  head -> 5 ---> 17 -> 23 -> 31 -> 40 -> 55 -> 71 ---> NULL
 *
 * Complexities (n = entries in the MemTable):
 *   search / insert (arbitrary key) : O(log n) expected
 *   insert of a key LARGER than every existing key : O(1) expected   <-- see below
 *   in-order scan of K entries      : O(K) after an O(log n) seek
 *
 * TIME-SERIES OPTIMISATION: sensor timestamps arrive in increasing order, so
 * almost every insert is an "append at the tail". We keep a per-level `tail[]`
 * array (the last node of every level). When the new key is larger than
 * max_key we skip the search entirely and splice at the tail: O(1) expected.
 * Out-of-order samples (late packets) transparently fall back to O(log n).
 *
 * Nodes are never physically removed. A delete is just an insert of a record
 * whose `tombstone` flag is 1 (lazy deletion); the flush/compaction code
 * decides later what to do with it.
 */
#ifndef SKIPLIST_H
#define SKIPLIST_H

#include "record.h"
#include <stddef.h>

#define SL_MAX_LEVEL 16

typedef struct SLNode {
    Record rec;
    int    level;
    struct SLNode *next[];          /* flexible array: `level` forward pointers */
} SLNode;

typedef struct {
    SLNode  *head;                  /* sentinel                                 */
    SLNode  *tail[SL_MAX_LEVEL];    /* last node at each level (O(1) append)    */
    int      level;                 /* highest level currently in use           */
    size_t   count;                 /* number of distinct keys                  */
    uint64_t max_key;               /* largest key present                      */
    uint64_t rng;                   /* xorshift state for random heights        */
    size_t   fast_appends;          /* statistics: O(1) tail inserts            */
    size_t   slow_inserts;          /* statistics: O(log n) inserts/updates     */
} SkipList;

SkipList      *sl_create(uint64_t seed);
void           sl_free(SkipList *sl);
/* Insert or overwrite. Returns 1 if a new key was added, 0 if overwritten. */
int            sl_put(SkipList *sl, const Record *r);
/* Exact lookup. Returns pointer to the stored record or NULL. */
const Record  *sl_get(const SkipList *sl, uint64_t key);
/* First node with key >= `key` (NULL if none): starting point for range scans. */
const SLNode  *sl_seek(const SkipList *sl, uint64_t key);
/* First node in sorted order (used when flushing). */
const SLNode  *sl_first(const SkipList *sl);

#endif /* SKIPLIST_H */
