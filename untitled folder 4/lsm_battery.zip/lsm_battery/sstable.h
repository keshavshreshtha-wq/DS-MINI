/*
 * sstable.h - Sorted String Table: an immutable, sorted file on disk.
 *
 * FILE LAYOUT
 *   +-----------------+----------------------+---------------------------+
 *   | Header (48 B)   | Bloom filter bits    | Records (32 B each)       |
 *   | count,min,max,  | (m bits, k hashes)   | sorted ascending by key   |
 *   | bloom m,k       |                      |                           |
 *   +-----------------+----------------------+---------------------------+
 *
 * IN-MEMORY METADATA kept for every open table:
 *   - min_key / max_key      -> skip the table if the key is outside the range
 *   - Bloom filter           -> skip the table if the key is definitely absent
 *   - sparse index           -> every 32nd key; binary search it, then read ONE
 *                               32-record block from disk (1 disk read / lookup)
 *
 * LOOKUP COST: range check O(1) + Bloom O(k) + binary search of the sparse
 * index O(log(n/32)) + one block read and scan O(32)  =>  O(log n).
 *
 * Files are never modified after creation (immutable) - compaction writes
 * new files and deletes old ones.
 */
#ifndef SSTABLE_H
#define SSTABLE_H

#include "record.h"
#include "bloom.h"
#include <stdio.h>

#define SST_SPARSE   32     /* one index entry per 32 records (= 1 disk "block") */
#define SST_ITER_BUF 64     /* records buffered by a sequential iterator          */

typedef struct {
    char magic[8];          /* "LSMSST01" */
    uint64_t count;
    uint64_t min_key, max_key;
    uint64_t bloom_nbits;
    uint32_t bloom_k;
    uint32_t reserved;
} SSTHeader;

typedef struct {
    char      path[300];
    FILE     *fp;           /* kept open, read-only                    */
    uint64_t  id;           /* creation sequence number (higher=newer) */
    int       level;        /* 0 = freshly flushed, higher = older/larger */
    uint64_t  count, min_key, max_key;
    uint64_t  data_offset;  /* byte offset of record #0                */
    Bloom    *bloom;
    uint64_t *index_keys;   /* sparse index: key of record 0, 32, 64.. */
    size_t    index_n;
} SSTable;

/* ---------- writing (used by MemTable flush and by compaction) ---------- */
typedef struct {
    FILE *fp; char path[300]; uint64_t id; int level;
    Bloom *bloom; uint64_t count, min_key, max_key, last_key; uint64_t data_offset;
} SSTWriter;

SSTWriter *sstw_begin(const char *path, uint64_t id, int level,
                      uint64_t max_entries, unsigned bloom_bits_per_key);
int        sstw_add(SSTWriter *w, const Record *r);     /* keys must be strictly ascending */
SSTable   *sstw_finish(SSTWriter *w);                   /* returns the opened table        */
void       sstw_abort(SSTWriter *w);                    /* discard (nothing was written)   */

/* ---------- reading ---------- */
SSTable *sst_open(const char *path, uint64_t id, int level);
void     sst_close(SSTable *t);

typedef enum {
    SST_OUT_OF_RANGE,   /* key < min or > max : rejected without any work      */
    SST_BLOOM_SKIP,     /* Bloom said "definitely absent": DISK READ AVOIDED   */
    SST_DISK_MISS,      /* block read from disk, key not there (false positive if Bloom on) */
    SST_FOUND           /* block read from disk, key found                     */
} SSTGetResult;

SSTGetResult sst_get(SSTable *t, uint64_t key, Record *out, int use_bloom);

/* ---------- sequential iterator (range scans and compaction) ---------- */
typedef struct {
    SSTable *t;
    uint64_t pos;                 /* next record index to load into buf */
    uint64_t skip_below;          /* drop records with key < skip_below */
    Record   buf[SST_ITER_BUF];
    size_t   buf_n, buf_i;
} SSTIter;

void sstit_seek(SSTIter *it, SSTable *t, uint64_t key);  /* position at first key >= `key` */
int  sstit_next(SSTIter *it, Record *out);               /* 1 = got a record, 0 = end      */

#endif /* SSTABLE_H */
