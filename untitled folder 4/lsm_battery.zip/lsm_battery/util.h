/*
 * util.h - tiny shared helpers: high-resolution timer, 64-bit hash mixer,
 *          ANSI colour switches for the console dashboard.
 */
#ifndef UTIL_H
#define UTIL_H

#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#ifdef _WIN32
  #include <windows.h>
  static inline uint64_t now_ns(void) {
      LARGE_INTEGER f, c;
      QueryPerformanceFrequency(&f);
      QueryPerformanceCounter(&c);
      return (uint64_t)((double)c.QuadPart * 1e9 / (double)f.QuadPart);
  }
#else
  /* Monotonic nanosecond clock (not affected by wall-clock adjustments). */
  static inline uint64_t now_ns(void) {
      struct timespec ts;
      clock_gettime(CLOCK_MONOTONIC, &ts);
      return (uint64_t)ts.tv_sec * 1000000000ull + (uint64_t)ts.tv_nsec;
  }
#endif

/* splitmix64 finaliser: a cheap, high-quality 64-bit integer hash.
 * Used by the Bloom filter (hashing) and by the RNGs. */
static inline uint64_t mix64(uint64_t x) {
    x += 0x9e3779b97f4a7c15ULL;
    x = (x ^ (x >> 30)) * 0xbf58476d1ce4e5b9ULL;
    x = (x ^ (x >> 27)) * 0x94d049bb133111ebULL;
    return x ^ (x >> 31);
}

/* ---- console colours (disabled with --no-color or NO_COLOR env var) ---- */
extern int g_use_color;
#define COL(code) (g_use_color ? (code) : "")
#define C_RESET   COL("\033[0m")
#define C_BOLD    COL("\033[1m")
#define C_DIM     COL("\033[2m")
#define C_RED     COL("\033[31m")
#define C_GREEN   COL("\033[32m")
#define C_YELLOW  COL("\033[33m")
#define C_BLUE    COL("\033[34m")
#define C_MAGENTA COL("\033[35m")
#define C_CYAN    COL("\033[36m")

#endif /* UTIL_H */
