#include "datagen.h"
#include <math.h>
#include <string.h>
#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

#define DT 0.1                       /* seconds per tick */

static double urand(SensorSim *s) {  /* uniform [0,1) via xorshift64* */
    uint64_t x = s->rng;
    x ^= x >> 12; x ^= x << 25; x ^= x >> 27;
    s->rng = x;
    return (double)((x * 2685821657736338717ULL) >> 11) / 9007199254740992.0;
}
static double noise(SensorSim *s, double amp) {   /* ~Gaussian-ish, zero mean */
    return amp * (urand(s) + urand(s) + urand(s) - 1.5) * 0.8;
}

void sim_init(SensorSim *s, uint64_t start_ms, uint64_t seed) {
    memset(s, 0, sizeof *s);
    s->start_ms = start_ms;
    s->rng = seed * 0x9E3779B97F4A7C15ULL + 1;
    s->flow = 1.5;
    s->coolant_in = 22.0;
    for (int i = 0; i < NUM_CELLS; i++) {
        s->temp[i] = 25.0 + noise(s, 0.5);
        s->soc[i]  = 0.95 - 0.005 * i;
    }
}

/* Advance the physical model by one 100 ms tick. */
static void step(SensorSim *s) {
    double t = (double)s->tick * DT;
    double tmax = 0;
    for (int i = 0; i < NUM_CELLS; i++) {
        /* drive cycle: 90 s cruise/accel cycle + 13 s ripple, small per-cell spread */
        double I = 8.0 + 6.0 * sin(2 * M_PI * t / 90.0)
                       + 2.0 * sin(2 * M_PI * t / 13.0 + i) + noise(s, 0.4);
        if (I < 0) I = 0;
        double R    = 0.025 * (1.0 + 0.02 * i);               /* ohm, slight cell-to-cell spread */
        double h    = 0.20 + 0.15 * s->flow;                  /* W/K cooling conductance         */
        double tcool = s->coolant_in + (0.6 / s->flow) * i;   /* coolant warms along the channel */
        double P    = I * I * R;                              /* Joule heating                   */
        s->temp[i] += (P - h * (s->temp[i] - tcool)) / 65.0 * DT;  /* C ~ 65 J/K for a 21700   */
        s->soc[i]  -= I * DT / (4.0 * 3600.0);                /* 4 Ah cell                       */
        s->cur[i]  = I;
        s->cool[i] = tcool;
        if (s->temp[i] > tmax) tmax = s->temp[i];
    }
    /* Toy "AI" thermal controller: more flow when the hottest cell is hot. */
    double target = 1.0 + 0.3 * (tmax - 28.0);
    if (target < 0.5) target = 0.5;
    if (target > 5.0) target = 5.0;
    s->flow += 0.05 * (target - s->flow);
}

void sim_next(SensorSim *s, Record *out) {
    if (s->idx == 0) step(s);
    unsigned i = s->idx;
    memset(out, 0, sizeof *out);
    uint64_t ts = s->start_ms + s->tick * 100;
    out->key = make_key(ts, i + 1);                           /* cell ids are 1..10 */
    out->battery_temperature = (float)(s->temp[i] + noise(s, 0.06));
    out->coolant_temperature = (float)(s->cool[i] + noise(s, 0.04));
    out->voltage             = (float)(3.2 + 0.95 * s->soc[i] - 0.025 * s->cur[i] + noise(s, 0.004));
    out->current             = (float)s->cur[i];
    out->coolant_flow_rate   = (float)(s->flow + noise(s, 0.02));
    if (++s->idx == NUM_CELLS) { s->idx = 0; s->tick++; }
}
