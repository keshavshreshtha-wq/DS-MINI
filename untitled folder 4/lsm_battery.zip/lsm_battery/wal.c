#include "wal.h"
#include <string.h>
#include <stdlib.h>
#ifndef _WIN32
  #include <unistd.h>
#endif

#define WAL_ENTRY_SIZE (sizeof(Record) + 4)

static uint32_t fnv1a(const uint8_t *p, size_t n) {
    uint32_t h = 2166136261u;
    for (size_t i = 0; i < n; i++) { h ^= p[i]; h *= 16777619u; }
    return h;
}

Wal *wal_open(const char *path, int do_fsync) {
    Wal *w = calloc(1, sizeof(Wal));
    snprintf(w->path, sizeof w->path, "%s", path);
    w->do_fsync = do_fsync;
    w->fp = fopen(path, "ab");
    if (!w->fp) { free(w); return NULL; }
    return w;
}

int wal_append(Wal *w, const Record *r) {
    uint8_t buf[WAL_ENTRY_SIZE];
    uint32_t crc = fnv1a((const uint8_t *)r, sizeof(Record));
    memcpy(buf, r, sizeof(Record));
    memcpy(buf + sizeof(Record), &crc, 4);
    if (fwrite(buf, 1, WAL_ENTRY_SIZE, w->fp) != WAL_ENTRY_SIZE) return -1;
    /* fflush hands the bytes to the OS, so they survive a *process* crash.
     * fsync additionally survives power loss, at a large latency cost. */
    if (fflush(w->fp) != 0) return -1;
#ifndef _WIN32
    if (w->do_fsync) fsync(fileno(w->fp));
#endif
    w->appended++;
    return 0;
}

int wal_reset(Wal *w) {
    fclose(w->fp);
    FILE *t = fopen(w->path, "wb");          /* "wb" truncates the file to 0 bytes */
    if (t) fclose(t);
    w->fp = fopen(w->path, "ab");
    w->appended = 0;
    return w->fp ? 0 : -1;
}

void wal_close(Wal *w) {
    if (!w) return;
    if (w->fp) fclose(w->fp);
    free(w);
}

size_t wal_replay(const char *path, void (*cb)(const Record *, void *), void *ud, int *clean) {
    *clean = 1;
    FILE *f = fopen(path, "rb");
    if (!f) return 0;
    uint8_t buf[WAL_ENTRY_SIZE];
    size_t n = 0;
    for (;;) {
        size_t got = fread(buf, 1, WAL_ENTRY_SIZE, f);
        if (got == 0) break;
        if (got < WAL_ENTRY_SIZE) { *clean = 0; break; }        /* torn tail */
        uint32_t crc;
        memcpy(&crc, buf + sizeof(Record), 4);
        if (crc != fnv1a(buf, sizeof(Record))) { *clean = 0; break; }
        Record r;
        memcpy(&r, buf, sizeof r);
        cb(&r, ud);
        n++;
    }
    fclose(f);
    return n;
}
