/*
 * wal.h - Write-Ahead Log.
 *
 * Rule: a mutation is appended to the WAL BEFORE it touches the MemTable.
 * If the process dies, the MemTable (RAM) is lost but the WAL file survives;
 * on restart we replay the WAL to rebuild it.
 *
 * On-disk entry = [ 32-byte Record | 4-byte FNV-1a checksum ]
 * A torn (half-written) last entry fails the checksum and is ignored.
 * Appending is purely sequential I/O: O(1) per write, no seeks.
 */
#ifndef WAL_H
#define WAL_H

#include "record.h"
#include <stdio.h>

typedef struct {
    FILE *fp;
    char  path[300];
    int   do_fsync;       /* 1 = force to physical disk on every append (slow, safest) */
    uint64_t appended;
} Wal;

Wal   *wal_open(const char *path, int do_fsync);               /* open for append */
int    wal_append(Wal *w, const Record *r);                    /* 0 on success    */
int    wal_reset(Wal *w);                                      /* truncate (after a successful flush) */
void   wal_close(Wal *w);

/* Replay every valid entry through `cb`. Returns number of entries replayed.
 * *clean is set to 0 if a corrupt/torn tail was found. */
size_t wal_replay(const char *path, void (*cb)(const Record *, void *), void *ud, int *clean);

#endif /* WAL_H */
