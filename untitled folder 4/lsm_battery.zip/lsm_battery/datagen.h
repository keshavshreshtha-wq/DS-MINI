/*
 * datagen.h - simulated sensor stream for the EV battery thermal system.
 *
 * Models 10 cylindrical 21700 Li-ion cells (C1..C10) cooled by a micro-channel
 * cold plate. Every 100 ms (10 Hz) each cell reports one sample, so 10 records
 * are produced per tick, in timestamp order.
 *
 * Physics (deliberately simple, but behaves plausibly):
 *   - drive-cycle current:  slow sinusoid + faster ripple + noise      [A]
 *   - Joule heating:        P = I^2 * R                                [W]
 *   - cooling:              h(flow) * (T_cell - T_coolant)             [W]
 *   - lumped thermal mass:  C * dT/dt = P - cooling                    [J/K]
 *   - coolant warms along the channel, so downstream cells run hotter
 *   - a simple "AI controller" raises the flow rate when the hottest cell
 *     gets warm (this is the signal an ML model would learn from)
 */
#ifndef DATAGEN_H
#define DATAGEN_H

#include "record.h"

typedef struct {
    double   temp[NUM_CELLS];     /* cell temperatures (state)  */
    double   soc[NUM_CELLS];      /* state of charge 0..1       */
    double   flow;                /* coolant flow, L/min        */
    double   coolant_in;          /* inlet coolant temperature  */
    uint64_t start_ms;
    uint64_t tick;                /* 100 ms steps               */
    unsigned idx;                 /* which cell is emitted next */
    uint64_t rng;
    double   cur[NUM_CELLS];      /* current of this tick       */
    double   cool[NUM_CELLS];     /* coolant temp at each cell  */
} SensorSim;

void sim_init(SensorSim *s, uint64_t start_ms, uint64_t seed);
/* Produce the next reading (round-robin C1..C10, then the next 100 ms tick). */
void sim_next(SensorSim *s, Record *out);

#endif /* DATAGEN_H */
