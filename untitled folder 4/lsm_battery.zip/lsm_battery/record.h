/*
 * record.h - the payload stored in the LSM-Tree.
 *
 * One Record = one sensor sample of ONE battery cell (C1..C10).
 *
 * KEY DESIGN:  key = (timestamp_ms << 4) | cell_id
 *   - Keys sort by timestamp first, then by cell id  -> the tree is
 *     "sorted by timestamp" exactly as required, and a time-window range
 *     query becomes a single contiguous key range [lo, hi].
 *   - cell_id needs 4 bits (we use 1..10), so there is no collision between
 *     two cells sampled at the same millisecond.
 *
 * The struct is exactly 32 bytes with no padding, so SSTables are simple
 * arrays of fixed-size records (record i lives at offset i*32) which makes
 * binary search / sparse indexing trivial.
 */
#ifndef RECORD_H
#define RECORD_H

#include <stdint.h>

#define NUM_CELLS 10
#define CELL_BITS 4

typedef struct {
    uint64_t key;               /* (timestamp_ms << 4) | cell_id            */
    float    battery_temperature; /* deg C  - cell surface temperature      */
    float    coolant_temperature; /* deg C  - coolant at that cell's channel*/
    float    voltage;             /* V                                      */
    float    current;             /* A      (+ = discharge)                 */
    float    coolant_flow_rate;   /* L/min  - micro-channel flow            */
    uint8_t  tombstone;           /* 1 = deletion marker (lazy delete)      */
    uint8_t  _pad[3];             /* explicit padding -> 32 bytes total     */
} Record;

_Static_assert(sizeof(Record) == 32, "Record must be exactly 32 bytes");

static inline uint64_t make_key(uint64_t ts_ms, unsigned cell_id) {
    return (ts_ms << CELL_BITS) | (cell_id & ((1u << CELL_BITS) - 1));
}
static inline uint64_t key_timestamp(uint64_t key) { return key >> CELL_BITS; }
static inline unsigned key_cell_id(uint64_t key)   { return (unsigned)(key & ((1u << CELL_BITS) - 1)); }

#endif /* RECORD_H */
