/*
 * lsm.h - the storage engine that ties everything together.
 *
 *   write path:  Record --> WAL (append) --> MemTable (skip list)
 *                                              | full?
 *                                              v
 *                                       flush --> SSTable (level 0)
 *                                              |  too many tables in a level?
 *                                              v
 *                                       compaction --> bigger SSTable (level+1)
 *
 *   read path :  MemTable --> SSTables, NEWEST first.
 *                For each SSTable: key-range check -> Bloom filter -> disk block.
 *
 * Compaction strategy: size-tiered. When a level holds `level_fanout` tables
 * they are merged into ONE table on the next level. Newer data shadows older
 * data; tombstones are purged when nothing older can be hiding below.
 */
#ifndef LSM_H
#define LSM_H

#include "record.h"
#include "skiplist.h"
#include "wal.h"
#include "sstable.h"

typedef struct {
    const char *dir;                  /* data directory                               */
    size_t   memtable_max_entries;    /* flush threshold                              */
    unsigned level_fanout;            /* tables per level that trigger compaction     */
    unsigned bloom_bits_per_key;      /* Bloom filter size                            */
    int      verbose;                 /* print flush / compaction events              */
    int      wal_fsync;               /* 1 = fsync every WAL append                   */
} LSMConfig;

typedef struct {
    uint64_t puts, deletes, gets, range_queries;
    uint64_t memtable_hits, sstable_hits, not_found;
    uint64_t range_skips;             /* tables rejected by min/max key range         */
    uint64_t bloom_negatives;         /* disk reads AVOIDED by the Bloom filter       */
    uint64_t bloom_false_pos;         /* Bloom said "maybe" but key was absent        */
    uint64_t disk_block_reads;        /* actual block reads performed                 */
    uint64_t flushes, compactions;
    uint64_t tombstones_purged, shadowed_dropped;
} LSMStats;

typedef enum {
    LOOKUP_FOUND_MEMTABLE,
    LOOKUP_FOUND_SSTABLE,
    LOOKUP_DELETED,                   /* a tombstone was found: record is deleted     */
    LOOKUP_NOT_FOUND
} LookupStatus;

typedef struct {                      /* what happened during one lookup (dashboard)  */
    int tables_probed, range_skips, bloom_skips, disk_reads;
    int bloom_false_pos;
    uint64_t source_table_id;
} LookupTrace;

typedef struct LSM {
    LSMConfig cfg;
    char      dir[256];
    SkipList *mem;                    /* MemTable                                     */
    Wal      *wal;
    SSTable **tables;                 /* sorted: level asc, then id desc (newest 1st) */
    size_t    ntables, cap;
    uint64_t  next_id;
    int       use_bloom;              /* toggle for the "with/without Bloom" demo     */
    size_t    recovered_entries;      /* entries replayed from the WAL on open        */
    LSMStats  stats;
} LSM;

LSM         *lsm_open(const LSMConfig *cfg);
void         lsm_close(LSM *db);               /* does NOT flush: WAL protects the RAM data */
void         lsm_wipe(const char *dir);        /* delete all files of a previous database    */

int          lsm_put(LSM *db, const Record *r);
int          lsm_delete(LSM *db, uint64_t key);
LookupStatus lsm_get(LSM *db, uint64_t key, Record *out, LookupTrace *trace);
/* All live readings with ts_lo <= timestamp <= ts_hi (cell_filter 0 = all cells).
 * Allocates *out; caller frees. Returns the number of records. */
size_t       lsm_range(LSM *db, uint64_t ts_lo, uint64_t ts_hi, unsigned cell_filter, Record **out);

int          lsm_flush(LSM *db);               /* MemTable -> new SSTable                  */
void         lsm_compaction_tick(LSM *db);     /* run the periodic compaction check        */
void         lsm_compact_all(LSM *db);         /* major compaction: everything -> 1 table  */
void         lsm_print_layout(const LSM *db);

#endif /* LSM_H */
