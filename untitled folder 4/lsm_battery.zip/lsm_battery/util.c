#include "util.h"
int g_use_color = 1;
